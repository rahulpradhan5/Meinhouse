(function($) {
    "use strict"

    new dlabSettings({
        version: "dark"
    });


})(jQuery);