<?php

namespace App\Http\Controllers;
use Validator, Input, Redirect, Hash; 
use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\Testimonial;
use App\Models\UserAddress;
use App\Models\User;
use App\Models\Contact;
use App\Models\Booking;
use Illuminate\Support\Facades\Auth;
use Session;
class HomeController extends Controller
{

    public function Index()
    {
        $services = Service::orderBy('name','ASC')->get();
        $testimonials = Testimonial::get();
        return view('website.index',compact('services','testimonials'));
    }

    public function About()
    {
        return view('website.about');
    }

    public function Service()
    {
        $data['services'] = Service::where('status','1')->orderBy('name','ASC')->get();
        return view('website.service',$data);
    }

    public function serviceDetail(Request $request,$url)
    {
        if(isset($url)){
            $booking = '';
            $service = Service::where('url',$url)->first();
            if(isset($service)){
                $popular_services = Service::orderBy('booking_count','DESC')->limit('5')->get();
                $addresses = array();
                if(auth::user()){
                    $addresses = UserAddress::where('user_id',auth::user()->id)->orderBy('id','DESC')->get();
                }
                if(isset($request->booking_id)){
                    $booking = Booking::where('id',$request->booking_id)->first();
                    return view('website.user_rebookings',compact('service','popular_services','addresses','booking'));
                }else{
					$services = Service::where('status',1)->orderBy('name','ASC')->get();
                    return view('website.serviceDetails',compact('service','services','popular_services','addresses'));
                }
            }else{
                return redirect('mississauga');
            }
        }else{
            return redirect('mississauga');
        }
    }
    public function contactUsPost(Request $request)
    {  
         $this->validate($request, [
            'email' => 'required',
            'phone' => 'required' ,
            'name' => 'required',
            'venue' => 'required',
            'message' => 'required'


        ]);
    
       
        //get contact  data
        $contactData = $request->all();
       
        $contact = new Contact;
        $contact->name = $request->name;
        $contact->email = $request->email;
        $contact->phone = $request->phone;
        $contact->venue = $request->venue;
        $contact->message = $request->message;
        $contact->save();
        return redirect('contact-us')->with('message','Details submitted successfully.We will contact you soon.');
       
    }
    public function Blog()
    {
        return view('website.blog');
    }
    public function blogdetail($url){
        $blog = Blog::where('url',$url)->first();
        if(isset($blog)){
            $count = $blog->views;
            $blog->views = $count + 1;
            $blog->save();
           return view('website.blogdetail',compact('blog')); 
        }else{
            
            return redirect('blog-post');
        }
        
    }
    public function Contact()
    {
        return view('website.contact');
    }

    
    public function proLogin()
    {
        return view('website.pro-login');
    }
    
    public function proRegister()
    {
        return view('website.pro-register');
    }

    public function Terms()
    {
        return view('website.terms');
    }

    public function privacyPolicy()
    {
        return view('website.privacy-policy');
    }

}
