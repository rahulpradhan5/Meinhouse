<?php

namespace App\Http\Controllers;

use App\Exports\ProfessionalExpo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Estimate;
use App\Models\Booking;
use App\Models\ProAvailability;
use App\Models\ProService;
use App\Models\ProDetail;
use App\Models\ProReview;

use Session;
use DB;
use Maatwebsite\Excel\Facades\Excel;
use Validator;
use Stripe;

class AdminControllerNew extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function login()
    {
        return view('admin_jobick.login');
    }
    
    public function login_post(Request $request)
    {
    
        $credentials = $request->only('email','password');
        if(Auth::attempt($credentials)){
          if(Auth::user()->role_id == 1){
            $useLoginId=User::where(['email'=>$request->email])->get();
    
            session()->put('admin-login-id',$useLoginId[0]->id);
            return redirect(url('admin/dashboard'));
    
          }else{
            Session::flush();
            Auth::logout();
            //return redirect(url('admin-login'));
    
             return back()->with('error','Invalid Username and Password.');
          }
        }else{
          return back()->with('error','Invalid Username and Password.');
        }
    }
    public function admin_dashboard()
    {
      $user = DB::table('users')->where('role_id','2')->count('id');
      $professional = DB::table('users')->where('role_id','3')->count('id');
      $pending_bookings = DB::table('bookings')->where('booking_status',0)->count();
      $accepted_bookings = DB::table('bookings')->where('booking_status',1)->count();
      $rejected_bookings = DB::table('bookings')->where('booking_status',2)->count();
      $payment_pending = DB::table('bookings')->where('booking_status',5)->count();
      $payment_done = DB::table('bookings')->where('booking_status',7)->count();
      $cancelled_bookings = DB::table('bookings')->where('booking_status',3)->count();
      $services = DB::table('services')->count();
       return view('admin_jobick.dashboard',compact('user','professional','pending_bookings','accepted_bookings','rejected_bookings','payment_pending','payment_done','cancelled_bookings','services'));
    }
    // User Operations Start
    public function user_index()
    {
        $data['user'] = DB::table('users')->where('role_id','2')->orderby('id','desc')->get();
        return view('admin_jobick.user.index',$data);
    }
    public function user_delete($id)
    {

      DB::table('users')->where('id',$id)->delete();
      return back()->with('success','User Deleted Successfully!');

    }
    public function user_view($id)
    {
       $data['users'] = User::where('id',$id)->first();
       $data['bookings'] = Booking::where('user_id',$id)->whereIn('booking_status',[0,1])->orderBy('id','DESC')->get();

        return view('admin_jobick.user.view_user',$data);
    }
    public function user_status(Request $request)
    {
      $id = $request->id;
      $result = DB::table('users')->where('id',$id)->get();
      $status = $result[0]->status;
      if($status=='1'){
        DB::table('users')->where('id',$id)->update(array('status'=>'0'));
        return $status;
        exit();
      }else{
        DB::table('users')->where('id',$id)->update(array('status'=>'1'));
        return $status;
        exit();
      }
    }
	public function user_state(Request $request)
    {

		 $id = $request->id;

      $result = DB::table('users')->where('id',$id)->get();
      $state = $result[0]->state;
      if($state=='1'){
        DB::table('users')->where('id',$id)->update(
        array('state'=>'0'));
        return $state;
        exit();
      }else{
        DB::table('users')->where('id',$id)->update(
      array('state'=>'1'));
      return $state;
      exit();
      }

    }
// User Operations End
// Professional Start
    public function professional()
    {
      $data['user'] = DB::table('users')->where('role_id','3')->orderby('id','desc')->get();
      return view('admin_jobick.professional.index',$data);
    }
    public function professional_view($id)
    {
        $users = User::where('id',$id)->first();
        $prodetails = ProDetail::where('pro_id',$id)->first();
        $proservices = ProService::where('pro_id',$id)->get();
        $bookings = Booking::where('pro_id',$id)->orderBy('id','DESC')->get();
        $reviews = ProReview::where('pro_id',$id)->orderBy('id','DESC')->get();
        $review_avg = ProReview::where('pro_id',$id)->orderBy('id','DESC')->avg('stars');
        $proavailability = ProAvailability::where('pro_id',$id)->get();
        $monday = ProAvailability::where('pro_id',$id)->where('day_id',1)->first();
        $tuesday = ProAvailability::where('pro_id',$id)->where('day_id',2)->first();
        $wednesday = ProAvailability::where('pro_id',$id)->where('day_id',3)->first();
        $thursday = ProAvailability::where('pro_id',$id)->where('day_id',4)->first();
        $friday = ProAvailability::where('pro_id',$id)->where('day_id',5)->first();
        $saturday = ProAvailability::where('pro_id',$id)->where('day_id',6)->first();
        $sunday = ProAvailability::where('pro_id',$id)->where('day_id',7)->first();
        $all = ProAvailability::where('pro_id',$id)->where('day_availability',1)->count();


        return view('admin_jobick.professional.details',compact('users','bookings','prodetails','proservices','proavailability','monday','tuesday','wednesday','thursday','friday','saturday','sunday','all','reviews','review_avg'));
    }
    public function professional_delete($id)
    {
        $user = user::where('id',$id)->delete();
        return back()->with('success','Professional Deleted Successfully!');
    }
    public function professional_edit($id)
    {
      $prodetails = ProDetail::where('pro_id',$id)->first();

      if(!$prodetails){
        return redirect('admin/professional')->with('error','Business Not Listed');	
      }
        $users = User::where('id',$id)->first();
        $prodetails = ProDetail::where('pro_id',$id)->first();
        return view('admin_jobick.professional.edit',compact('users','prodetails'));
    
    }
    
    public function professional_update(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
        'company_name'=>'max:50|min:0',
        'business_address'=>'max:50|min:0',
        'phone_no'=>'max:20|min:0',
        'name'=>'max:50|min:0',
        'address'=>'max:50|min:0',
        'city'=>'max:50|min:0',
        'province'=>'max:50|min:0',
        'postal_code'=>'max:50|min:0',
        'experience'=>'max:50|min:0',
        'distance'=>'max:50|min:0',
        'ein_no'=>'max:50|min:0',
        'acc_first_name'=>'max:50|min:0',
        'acc_last_name'=>'max:50|min:0',
        'ssn_no'=>'max:50|min:0',
        'dob'=>'max:50|min:0',
        'routing_no'=>'max:50|min:0',
        'account_no'=>'max:50|min:0',
        'license_no'=>'max:50|min:0',
        'routing_no'=>'max:50|min:0',
        
        ]);

		if($validator->fails()){
		return redirect()->back()
		->withErrors($validator)
		->withInput();
		}
		 $userprofile = ProDetail::where('id',$request->editId)->first();
		if($request->file('file')){
      $imageName = time().'.'.$request->file->extension();
      $request->file->move(public_path('/upload/pro_doc'), $imageName);
		}else{
      $imageName=$request->input('OldImg');
		}
		
		if($request->file('passport_loc')){
			$PassPortimage = time().'.'.$request->passport_loc->extension();
      $request->passport_loc->move(public_path('/upload/pro_doc'),$PassPortimage);
      $userprofile->insurance=$PassPortimage;
			
		}else{

      $userprofile->insurance=$request->OLDpassport_loc;
		}

      

      $userprofile->company_name=$request->company_name;
      $userprofile->business_address=$request->business_address;
      $userprofile->phone_no=$request->phone_no;
      $userprofile->commission_perc=$request->commission_perc;
      $userprofile->com_ind=$request->com_ind;
      $userprofile->ein_no=$request->ein_no;
      $userprofile->acc_first_name=$request->acc_first_name;
      $userprofile->acc_last_name=$request->acc_last_name;
      $userprofile->ssn_no=$request->ssn_no;
      $userprofile->dob=$request->dob;
      $userprofile->routing_no=$request->routing_no;
      $userprofile->account_no=$request->account_no;
      $userprofile->license_no=$request->license_no;
      $userprofile->license_doc=$imageName;
      $userprofile->transaction_id=$request->transaction_id;
      $userprofile->amount=$request->amount;
      $userprofile->name=$request->name;
      $userprofile->address=$request->address;
      $userprofile->city=$request->city;
      $userprofile->province=$request->province;
      $userprofile->postal_code=$request->postal_code;
      $userprofile->experience=$request->experience;
      $userprofile->vehicle_owner=$request->vehicle_owner;
      
      $userprofile->distance=$request->distance;
      $userprofile->criminal_offence=$request->criminal_offence;
      
		
		
		if($userprofile->update()){
	//return redirect()->to('job_view/'.$id);
	//	return redirect('/admin/professional/edit/'.$request->pro_id)->with('success','Data updated successfully.');
        return redirect('admin/professional')->with('success','Professional updated successfully.');
			
		}else{
      return back()->with('error','An Error Occured!');
		}

		}

// Professional end
    public function estimate()
    {
      $data['estimate'] = DB::table('estimates')->orderby('id','desc')->get();
      return view('admin_jobick.estimate.index',$data);
    }

    public function service_index()
    {
      $data['services'] = DB::table('services')->orderby('id','desc')->get();
      return view('admin_jobick.service.index',$data);
    }

    public function bookings_index()
    {
      $data['bookings'] = DB::table('bookings')->orderby('id','desc')->get();
      return view('admin_jobick.bookings.index',$data);
    }

    public function sales_index()
    {
      $data['bookings'] = DB::table('custom_bookings')->orderby('id','desc')->get();
      return view('admin_jobick.sales.index',$data);
    }


    public function transaction_index()
    {
      $data['bookings'] = DB::table('user_transactions')->orderby('id','desc')->get();
      return view('admin_jobick.transaction.index',$data);
    }

    public function promo_index()
    {
      $data['bookings'] = DB::table('promocodes')->orderby('id','desc')->get();
      return view('admin_jobick.promo.index',$data);
    }
    public function testimonial()
    {
      $data['testimonial'] = DB::table('testimonials')->orderby('id','desc')->get();
      return view('admin_jobick.testimonial.index',$data);
    }
    public function contact()
    {
      $data['contact'] = DB::table('contacts')->orderby('id','desc')->get();
      return view('admin_jobick.contact.index',$data);
    }
    public function blog()
    {
      $data['blog'] = DB::table('blogs')->orderby('id','desc')->get();
      return view('admin_jobick.blog.index',$data);
    }
}
