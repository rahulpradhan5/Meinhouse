<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;



class Custom_orders extends Model
{
    protected $table = 'custom_orders';
}