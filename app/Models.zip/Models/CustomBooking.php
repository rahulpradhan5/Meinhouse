<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;


class CustomBooking extends Model
{
    public function userDetails(){

    	return $this->belongsTo('App\User','user_id','id');
    }

     public function serviceDetails(){

    	return $this->belongsTo('App\Service','service_id','id');
    }
}
