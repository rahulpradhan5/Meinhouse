

        <div class="footer">
            <div class="copyright">
                <p>Copyright © 2020 Mein Haus. All rights reserved. </p>
            </div>
        </div>
    <!--**********************************
        Scripts
    ***********************************-->

    <!-- Required vendors -->
    <script src="{{url('assets/jobick/vendor/global/global.min.js')}}"></script>
	<script src="{{url('assets/jobick/vendor/chart.js/Chart.bundle.min.js')}}"></script>
	<script src="{{url('assets/jobick/vendor/jquery-nice-select/js/jquery.nice-select.min.js')}}"></script>

	<!-- Apex Chart -->
	<script src="{{url('assets/jobick/vendor/apexchart/apexchart.js')}}"></script>

    <script src="{{url('assets/jobick/vendor/datatables/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{url('assets/jobick/js/plugins-init/datatables.init.js')}}"></script>

	<script src="{{url('assets/jobick/vendor/chart.js/Chart.bundle.min.js')}}"></script>

	<!-- Chart piety plugin files -->
    <script src="{{url('assets/jobick/vendor/peity/jquery.peity.min.js')}}"></script>

	<!-- Dashboard 1 -->
	<script src="{{url('assets/jobick/js/dashboard/dashboard-1.js')}}"></script>

	<script src="{{url('assets/jobick/vendor/owl-carousel/owl.carousel.js')}}"></script>


    <script src="{{url('assets/jobick/vendor/toastr/js/toastr.min.js')}}"></script>
    <script src="{{url('assets/jobick/js/plugins-init/toastr-init.js')}}"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="{{url('assets/jobick/vendor/jquery-nice-select/js/jquery.nice-select.min.js')}}"></script>
	<script src="{{url('assets/jobick/vendor/ckeditor/ckeditor.js')}}"></script>
    <script src="{{url('assets/jobick/js/custom.min.js')}}"></script>
	<script src="{{url('assets/jobick/js/dlabnav-init.js')}}"></script>

    <script src="{{url('assets/jobick/vendor/select2/js/select2.full.min.js')}}"></script>
    <script src="{{url('assets/jobick/js/plugins-init/select2-init.js')}}"></script>

