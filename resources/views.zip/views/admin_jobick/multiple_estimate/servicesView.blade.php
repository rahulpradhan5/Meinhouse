@extends('admin_jobick.layout.layout')
@section('content')

    <div class="row page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)">Estimate</a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)">Assign Professional</a></li>
        </ol>
    </div>

    <div class="row">
        @foreach ($ms_filter as $ms)
            <div class="col-12">
                <div class="card card-info">
                    <!-- form start -->
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label">Booking Id</label>
                            <label for="inputEmail3" class="col-sm-2 col-form-label"><B>:</B></label>
                            <div class="col-sm-6">
                                <span class="">{{ $m_est[0]->booking_show_id }}</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label">Service Name</label>
                            <label for="inputEmail3" class="col-sm-2 col-form-label"><B>:</B></label>
                            <div class="col-sm-6">
                                <span class=""><?php $service = DB::table('services')
                                    ->where('id', $ms->service_id)
                                    ->get();
                                echo $service[0]->name; ?></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label">Project
                                Description</label>
                            <label for="inputEmail3" class="col-sm-2 col-form-label"><B>:</B></label>
                            <div class="col-sm-6">
                                <span class="">{{ ucwords($ms->description) }}</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label">Amount</label>
                            <label for="inputEmail3" class="col-sm-2 col-form-label"><B>:</B></label>
                            <div class="col-sm-6">
                                <span class="">{{ ucwords($ms->amount) }}</span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-4 col-form-label">Registration Amount</label>
                            <label for="inputEmail3" class="col-sm-2 col-form-label"><B>:</B></label>
                            <div class="col-sm-6">
                                <span class="">{{ ucwords($ms->reg_amount) }}</span>
                            </div>
                        </div>




                    </div>

                    <?php
                    $check = DB::table('multiple_estimate_professionals')
                        ->where('mest_service_id', $ms->id)
                        ->where('status', 1)
                        ->exists();
                    ?>
                    @if ($check == null)
                        <div class="card-footer">
                            <a href="{{ url('admin/multiple-estimate-bid/' . $ms->id . '/' . $m_est[0]->booking_show_id) }}"
                                class="btn btn-success text-white float-end ms-3 btn-xs">Bid <i
                                class="fas fa-arrow-right fa-xs"></i></a>
                            <a href="{{ url('admin/assign-service/' . $ms->id . '/' . $m_est[0]->booking_show_id) }}"
                                class="btn btn-info text-white float-end btn-xs">Assign <i
                                    class="fas fa-arrow-right fa-xs"></i></a>
                        </div>
                    @elseif($check != null)
                        <div class="card-footer">
                            <a class="btn btn-secondary text-white float-end btn-xs" disabled>Assigned</a>
                        </div>
                    @endif
                </div>
                <!-- /.card -->
            </div>
        @endforeach
    </div>


@endsection
