@extends('admin_jobick.layout.layout')
@section('content')
    <div class="row page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item "><a href="javascript:void(0)">Estimate</a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)">Edit</a></li>
        </ol>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Estimate Detail</h4>
                </div>
                <div class="card-body">
                    <form class="form-horizontal" method="POST" name="update-service"
                        action="{{url('admin/multiple-estimate/edit-post')}}" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group mb-2 row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">User Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="name" name="user_id"
                                    placeholder="User name" value="{{ucwords($data[0]->name)}}" required>
                            </div>
                        </div>

                        <div class="form-group mb-2 row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">User Email</label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" id="name" name="email"
                                    placeholder="User Email" value="{{ucwords($data[0]->email)}}" required>
                            </div>
                        </div>

                        <div class="form-group mb-2 row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Select Date</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="date" name="date"
                                    placeholder="Select Date" value="<?php if(empty($data[0]->date)){echo "Null";}else{echo $data[0]->date;}?>" autocomplete="off">
                            </div>
                        </div>

                        <div class="form-group mb-2 row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Address</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="address" name="address"
                                    placeholder="Enter Address" value="{{ucwords($data[0]->address)}}" required>
                            </div>
                        </div>

                        <div class="form-group mb-2 row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">City/Municipality</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="city" name="city" placeholder="Enter City/Municipality" required value="{{$data[0]->city}}">
                            </div>
                        </div>

                        <div class="form-group mb-2 row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Province</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="state" name="state" placeholder="Enter Province" required value="{{$data[0]->state}}">
                            </div>
                        </div>

                        <div class="form-group mb-2 row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Postal Code</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="pin_code" name="pin_code" placeholder="Enter Postal Code" required value="{{$data[0]->pincode}}">
                            </div>
                        </div>

                        <div class="form-group mb-2 row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Contact Number</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Enter Contact Number" required value="{{$data[0]->phone_no}}">
                            </div>
                        </div>

                        <input type="hidden" name="booking_id" value="{{$data[0]->booking_show_id}}">

                        <div class="card-footer">
                            <button type="submit" class="btn btn-info">Update Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
    <script type="text/javascript">
        $(function() {
            $('#colorselector').change(function() {
                $('.timees').hide();
                $('.colors').hide();
                $('#' + $(this).val()).show();
            });
        });
    </script>
@endsection
