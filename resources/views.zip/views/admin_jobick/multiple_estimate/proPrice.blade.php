@extends('admin_jobick.layout.layout')
@section('content')
    <div class="row page-titles">
        <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item "><a href="javascript:void(0)">Estimate</a></li>
            <li class="breadcrumb-item active"><a href="javascript:void(0)">Professional Assignment</a></li>
        </ol>
    </div>
    @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <?php
    $check = DB::table('multiple_estimate_professionals')
        ->where('mest_service_id', $data[0]->id)
        ->where('status', 1)
        ->exists();
    ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Professional Assignment</h4>
                </div>
                <div class="card-body">

                    <form class="form-horizontal" method="POST" name="add-sales" id="add-sales"
                        action="{{ url('admin/assign-service-post') }}" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">

                            <div class="form-group row mb-4">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Booking
                                        ID</b></label>
                                <div class="col-sm-10 mt-1">
                                    <font color="red"><b>{{ $bookingId }}</b></font>
                                </div>
                            </div>

                            <div class="form-group row mb-4">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Project
                                        Description</b></label>
                                <div class="col-sm-10 mt-1">
                                    <font color="red"><b>{{ ucfirst($data[0]->description) }}</b></font>
                                </div>
                            </div>

                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Assign
                                        Direct</b></label>
                                <div class="col-sm-10">
                                    <select name="professional" class="form-control" required>
                                        <?php
                                        $pro = DB::table('users')
                                            ->where('role_id', 3)
                                            ->get(['id', 'name']);
                                        ?>
                                        @foreach ($pro as $key => $value)
                                            <option value="{{ $value->id }}">{{ ucwords($value->name) }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Pro
                                        Amount</b></label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" name="customamount" maxlength="20" required
                                        placeholder="Enter Professional Amount">
                                </div>
                            </div>

                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Start
                                        Date</b></label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" name="sdate" required
                                        placeholder="Select Start Date">
                                </div>
                            </div>

                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Notes</b></label>
                                <div class="col-sm-10">
                                    <textarea row="5" cols="20" class="form-control" name="notes" required placeholder="Enter Description"></textarea>
                                </div>
                            </div>

                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Attachment</b></label>
                                <div class="col-sm-10">
                                    <input type="file" required class="form-control" name="attachment">
                                </div>
                            </div>

                            <?php $address_book = DB::table('multiple_estimate')
                                ->where('id', $data[0]->estimate_id)
                                ->get(); ?>
                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Address</b></label>
                                <div class="col-sm-10">
                                    <input type="text" maxlength="240" class="form-control"
                                        value="{{ $address_book[0]->address }}" disabled style="background-color: rgb(247, 247, 247)">
                                    <input type="hidden" value="{{ $address_book[0]->address }}" name="address">
                                </div>
                            </div>

                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1"
                                    class="col-sm-2 col-form-label"><b>City/Municipality</b></label>
                                <div class="col-sm-10">
                                    <input type="text" maxlength="240" class="form-control"
                                        value="{{ $address_book[0]->city }}" disabled style="background-color: rgb(247, 247, 247)">
                                    <input type="hidden" value="{{ $address_book[0]->city }}" name="city">
                                </div>
                            </div>

                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Province</b></label>
                                <div class="col-sm-10">
                                    <input type="text" maxlength="240" class="form-control"
                                        value="{{ $address_book[0]->state }}" disabled style="background-color: rgb(247, 247, 247)">
                                    <input type="hidden" value="{{ $address_book[0]->state }}" name="province">
                                </div>
                            </div>

                            <div class="form-group row mb-2">
                                <label for="exampleInputEmail1" class="col-sm-2 col-form-label"><b>Postal
                                        Code</b></label>
                                <div class="col-sm-10">
                                    <input type="text" maxlength="7" class="form-control"
                                        value="{{ $address_book[0]->pincode }}" disabled style="background-color: rgb(247, 247, 247)">
                                    <input type="hidden" value="{{ $address_book[0]->pincode }}" name="postal_code">
                                </div>
                            </div>

                            <input type="hidden" name="booking_id" value="{{ $address_book[0]->booking_show_id }}">
                            <input type="hidden" name="mest_service_id" value="{{ $data[0]->id }}">


                        </div>

                        @if ($check == null)
                            <div class="card-footer">
                                <center><button type="submit" class="btn btn-info">Finish</button></center>
                            </div>
                        @endif

                    </form>

                </div>
            </div>
        </div>
    </div>
@endsection
