@extends('professional.layout.layout')
@section('content')
<style type="text/css">
    .label-danger {
        background-color: #d9534f;
    }

    .card-primary:not(.card-outline) .card-header {
        background-color: #17a2b8;
    }

    .label {
        display: inline;
        padding: .2em .6em .3em;
        font-size: 75%;
        font-weight: 700;
        line-height: 1;
        color: #fff;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: .25em;
    }

    .label-success {
        background-color: #5cb85c;
    }

    .pt-0 {
     
       margin-top: 16px !important;
    }
    .card {
      margin-bottom: 1.875rem;
      background-color: #fff;
      transition: all .5s ease-in-out;
      position: relative;
      border: 0rem solid transparent;
      border-radius: 1.25rem;
      box-shadow: 0rem 0.3125rem 0.3125rem 0rem rgba(82, 63, 105, 0.05);
      height: auto;
      }
</style>
@csrf

<!-- Info boxes -->
<div class="row">
    <!-- /.row -->
    <!--start-->
    <!-- @if (session('error'))
       <div class="alert alert-danger" >
          {{ session('error') }}
       </div>
       @endif
       @if (session('success'))
       <div class="alert alert-success">
          {{ session('success') }}
       </div>
       @endif -->
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header">
                <h3 class="card-title">Estimate</h3>
            </div>
            <br>
            <div class="card-body" >
                @forelse($data as $key=> $value)
                <div class="card">
                    @php
                    if($value->time == 0){
                    $timeval = 'Morning(8-11 AM)';
                    }
                    if($value->time == 1){
                    $timeval = 'Midnoon(11-2 PM)';
                    }
                    if($value->time == 2){
                    $timeval = 'Afternoon(2-5 PM)';
                    }
                    if($value->time == 3){
                    $timeval = 'Evening(5-8 PM)';
                    }
                    @endphp
                    <div class="card-body ">
                        <div class="row">
                            <div class="col-7">
                                <h2 class="lead"><b>{{ucwords($value->name)}}</b></h2>
                                <p class="text-muted text-sm"><b>Service: </b> {{$value->service}} </p>
                                <ul class="ml-4 mb-0 fa-ul text-muted">
                                    <li class="small"><span class="fa-li"><i class="fas fa-bookmark"></i></span> Booking
                                        ID #: {{$value->estimate_booking_id}} </li>
                                    <li class="small"><span class="fa-li"><i class="fas fa-bookmark"></i></span>
                                        Description #: {{$value->notes}} </li>

                                    @if($value->attachment==NULL)
                                    <li class="h6 ml-1 mt-1"><a href="javascript:void()" data-bs-toggle="modal"
                                            data-bs-target="#myModal{{$value->id}}"><span class="fa-li"><i
                                                    class="fas fa-link mt-1"></i></span> Attachment</a> </li>
                                    <?php
                                $t = DB::table('estimates_bidding_images')->where('estimate_booking_id',$value->estimate_booking_id)->get();
                                ?>
                                    <div class="modal fade" id="myModal{{$value->id}}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                            <div class="modal-header">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        @if(count($t))
                                                        @foreach($t as $if)
                                                        <div class="col-lg-3 mt-2  mx-auto img-fluid">
                                                                    <?php $extension = pathinfo(url('public/bid_attachment/'.$if->image), PATHINFO_EXTENSION);?>
                                                                    @if($extension=='pdf')
                                                                    <a href="{{url('public/bid_attachment/'.$if->image)}}"
                                                                        target="_blank"><img
                                                                            src="{{url('public/bid_attachment/pdf.png')}}"
                                                                            style="height:100px;width:100px;"></a>
                                                                    @else
                                                                    <a href="{{url('public/bid_attachment/'.$if->image)}}"
                                                                        target="_blank"><img
                                                                            src="{{url('public/bid_attachment/'.$if->image)}}"
                                                                            style="height:100px;width:150px;"></a>
                                                                    @endif
                                                        </div>
                                                        @endforeach
                                                        @else
                                                        <!--<div class="card text-center">-->
                                                        <!--    <div class="card-body">-->
                                                        <h4 class="mt-3 ml-3">Not Found..</h4>

                                                        <!--    </div>-->
                                                        <!--</div>-->
                                                        @endif
                                                    </div>
                                                    <br>
                                                </div>
                                                <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              </div>
                                            </div>
                                        </div>
                                    </div>
                                    @else
                                    <li class="h6 ml-1 mt-1"><a href="{{ url('public/attachment/'.$value->attachment)}}"
                                            target="_blank"><span class="fa-li"><i class="fas fa-link mt-1"></i></span>
                                            Attachment</a> </li>
                                    @endif


                                </ul>
                            </div>
                            <div class="col-5 ">
                                <ul class="ml-4 mb-0 fa-ul text-muted">
                                    <li class="small"><span class="fa-li"><i class="fas fa-calendar-minus"></i></span>
                                        {{date('d.m.Y', strtotime($value->assign_date))}} </li>
                                    <li class="small"><span class="fa-li"><i class="far fa-clock"></i></span>
                                        {{$timeval}} </li>
                                    <li class="small"><span class="fa-li"><i class="fas fa-dollar-sign"></i></span>
                                        {{$value->pro_amount}} </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="ms-auto" style="width: fit-content;">
                            @if($value->assign_status == 0)
                            <a href="{{url('pro/estimate/1/'.$value->id)}}" class="btn btn-sm btn-primary ms-auto">
                                Accept
                            </a>
                            <a href="{{url('pro/estimate/2/'.$value->id)}}" class="btn btn-sm btn-primary ms-auto">
                                Decline
                            </a>
                            @elseif($value->assign_status == 1)
                            <a href="javascrpit:void(0);" class="btn btn-sm btn-success ms-auto">
                                Accepted
                            </a>
                            @elseif($value->assign_status == 2)
                            <a href="javascrpit:void(0);" class="btn btn-sm btn-danger ms-auto">
                                Declined
                            </a>
                            @endif
                        </div>
                    </div>
                </div>
                @empty
                <div class="card bg-light">
                    <center class="p-3">No Estimate Available</center>
                </div>
                @endforelse
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
    </div>
</div>
    @endsection
    @section('script')
    <script type="text/javascript">
        function myFunction(id) {

            swal({

                title: "Are you sure?",

                text: "You will not be able to recover this detail!",

                type: "warning",

                showCancelButton: true,

                confirmButtonClass: 'btn-danger',

                confirmButtonText: 'Yes, delete it!',

                cancelButtonText: "No, cancel please!",

                closeOnConfirm: false,

                closeOnCancel: true

            },

                function (isConfirm) {

                    if (!isConfirm) return;

                    $.ajax({

                        url: "{{ url('admin/contactus/delete/') }}/" + id,

                        type: "GET",

                        dataType: "html",

                        success: function () {

                            swal("Done!", "Detail succesfully deleted!", "success");

                            location.reload();

                        },

                        error: function (xhr, ajaxOptions, thrownError) {

                            swal("Error deleting!", "Please try again", "error");

                        }

                    });

                });

        };

    </script>
    @endsection