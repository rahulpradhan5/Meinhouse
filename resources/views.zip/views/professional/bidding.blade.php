@extends('professional.layout.layout')
@section('content')

<style type="text/css">
    .label-danger {

        background-color: #d9534f;

    }

    .card-primary:not(.card-outline) .card-header {

        background-color: #17a2b8;

    }
    .card {
      margin-bottom: 1.875rem;
      background-color: #fff;
      transition: all .5s ease-in-out;
      position: relative;
      border: 0rem solid transparent;
      border-radius: 1.25rem;
      box-shadow: 0rem 0.3125rem 0.3125rem 0rem rgba(82, 63, 105, 0.05);
      height: auto;
      }
    .label {

        display: inline;

        padding: .2em .6em .3em;

        font-size: 75%;

        font-weight: 700;

        line-height: 1;

        color: #fff;

        text-align: center;

        white-space: nowrap;

        vertical-align: baseline;

        border-radius: .25em;

    }

    .label-success {

        background-color: #5cb85c;

    }

    .pt-0 {

        margin-top: 16px !important;

    }
</style>

<!--@csrf-->

<!-- Info boxes -->

<div class="row">


    <div class="col-md-12">

        <div class="card ">

            <div class="card-header">

                <h3 class="card-title">Bidding</h3>

            </div>

            <br>



            <div class="card-body">

                @forelse($data as $key=> $value)

                <div class="card">

                    <div class="card-body ">

                        <div class="row">

                            <div class="col-7">

                                <h2 class="lead"><b>{{ucwords($value->name)}}</b></h2>

                                <p class="text-muted text-sm"><b>Service: </b> {{$value->service}} </p>

                                <ul class="ml-4 mb-0 fa-ul text-muted">

                                    <li class="small"><span class="fa-li"><i class="fas fa-bookmark"></i></span> Booking
                                        ID #: {{$value->booking_id}} </li>

                                    <li class="small"><span class="fa-li"><i class="fas fa-bookmark"></i></span>
                                        Description #: {{$value->notes}} </li>

                                    <li class="small"><span class="fa-li"><i class="fas fa-calendar-minus"></i></span>
                                        Start Date : {{date('d.m.Y', strtotime($value->start_date))}} </li>

                                    <li class="small"><span class="fa-li"><i class="fas fa-street-view"></i></span>
                                        Locality / Area : {{$value->eb_locality}} </li>

                                    <li class="small"><span class="fa-li"><i class="fas fa-dollar-sign"></i></span>
                                        Amount : {{$value->pro_amount}} </li>

                                    <!--<li class="h6 ml-1 mt-1"><a href="{{ url('public/bid_attachment/'.$value->atc)}}" target="_blank"><span class="fa-li"><i class="fas fa-link mt-1"></i></span> Attachment</a> </li>-->

                                    <li class="h6 ml-1 mt-1"><a href="javascript:void()" type="button" data-bs-toggle="modal" data-bs-target="#myModal{{$value->id}}" ><span class="fa-li"><i
                                                    class="fas fa-link mt-1"></i></span> Attachment</a> </li>

                                </ul>

                            </div>



                            <?php

                        $t = DB::table('estimates_bidding_images')->where('estimate_booking_id',$value->booking_id)->get();

                        ?>

                        <!-- Modal -->
                        <div class="modal fade" id="myModal{{$value->id}}" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                           <div class="modal-content">
                              <div class="modal-header">
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                 <div class="row">

                                 @if(count($t))

                                 @foreach($t as $if)

                                 <div class="col-lg-3 mt-2  mx-auto img-fluid">

                                             <?php $extension = pathinfo(url('public/bid_attachment/'.$if->image), PATHINFO_EXTENSION);?>

                                             @if($extension=='pdf')

                                             <a href="{{url('public/bid_attachment/'.$if->image)}}"
                                                target="_blank"><img
                                                   src="{{url('public/bid_attachment/pdf.png')}}"
                                                   style="height:100px;width:100px;"></a>

                                             @else

                                             <a href="{{url('public/bid_attachment/'.$if->image)}}"
                                                target="_blank"><img
                                                   src="{{url('public/bid_attachment/'.$if->image)}}"
                                                   style="height:100px;width:150px;"></a>

                                             @endif

                                 </div>

                                 @endforeach

                                 @else

                                 <!--<div class="card text-center">-->

                                 <!--    <div class="card-body">-->

                                 <h4 class="mt-3 ml-3">Not Found..</h4>



                                 <!--    </div>-->

                                 <!--</div>-->

                                 @endif

                                 </div>
                              </div>
                              <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                        </div>

                           









                            <div class="col-5 ">

                                <ul class="ml-4 mb-0 fa-ul text-muted">



                                    <form method="post" action="{{ route('pro-bid-update') }}" class="mt-4">

                                        @csrf

                                        @if($value->bidding_amount==NULL)

                                        <input type="hidden" name="bid_id" value="{{ $value->id }}">

                                        <div class="form-group">

                                            <input type="number" name="bidding_amount" class="form-control"
                                                placeholder="Enter Bidding Amount.." required>

                                            <textarea class="form-control mt-3" rows="3" placeholder="Enter Comments.."
                                                name="comment" maxlength="300" required></textarea>

                                            @error('bidding_amount')

                                            <div class="validate_err">{{ $message }}</div>

                                            @enderror

                                        </div>

                                        @endif



                                </ul>

                            </div>

                        </div>

                    </div>

                    <div class="card-footer">

                        <div class="text-right">

                            @if($value->bidding_amount==NULL)

                            <input type="submit" class="btn btn-sm btn-primary" value="send">

                            @endif

                            <!--<a href="#" class="btn btn-sm btn-primary">Send</a>-->

                        </div>

                    </div>

                    </form>

                </div>

                @empty

                <div class="card bg-light">

                    <center><br>No Bid Available<br><br></center>

                </div>

                @endforelse

            </div>

            <!-- /.card-body -->

        </div>

        <!-- /.card -->

    </div>

</div>

    @endsection