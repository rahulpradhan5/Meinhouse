@extends('professional.layout.layout')
@section('content')
<style type="text/css">
    <?php
error_reporting(0);
?>
    .profile-picture-container .profile-picture-group {
        position: relative;
        width: 94px;
        height: 94px;
        display: block;
        margin: 0 auto;
    }

    .profile-picture-container .profile-picture-group .profile-picture {
        border-radius: 50%;
        width: 100px;
    }

    .profile-picture-container .profile-picture-group .profile-picture-button {
        position: absolute;
        bottom: 0;
        right: 0;
        margin-bottom: 0;
        cursor: pointer;
    }

    .profile-input {
        width: 884px !important;
        height: 45px !important;

    }

    input#file-input {
        display: none;
    }
</style>
<div class="row">
  <div class="card card-info">
      <div class="card-header">
          <h3 class="card-title">Customer Reviews</h3>
      </div>
      <div class="card-body">
          <div class="row">
              @if (session('error'))
              <div class="alert alert-danger">
                  {{ session('error') }}
              </div>
              @endif
              @if (session('success'))
              <div class="alert alert-success">
                  {{ session('success') }}
              </div>
              @endif
              <div class="col-12 col-md-12 col-lg-12 order-2 order-md-1">
                  <div class="row">
                      <div class="col-12 col-sm-6">
                          <div class="info-box ">
                              <div class="info-box-content">
                                  <span class="info-box-text text-center text-muted">Average Rating</span>
                                  <span class="info-box-number text-center text-muted mb-0"> {{$review_avg}}</span>
                              </div>
                          </div>
                      </div>
                      <div class="col-12 col-sm-6">
                          <div class="info-box ">
                              <div class="info-box-content">
                                  <span class="info-box-text text-center text-muted">Total Number of Reviews</span>
                                  <span class="info-box-number text-center text-muted mb-0">{{$review_count}}</span>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div class="row">
                          <h5>Customer Review and Rating Details</h5>
                          @forelse($reviews as $key => $data)
                          <div class="col-6">
                              <div class="card-body row">
                                  <div class="col-md-4">
                                      <div class="profile-picture-container">
                                          <div class="profile-picture-group">
                                              <img class="profile-picture"
                                                  src="{{$data['userDetails']['user_image'] ? url('public/uploads/users/'.$data['userDetails']['user_image']) : url('assets/jobick/images/logo.png')}}"
                                                  height="90" width="100" style="border-radius: 50%">
                                                @php
                                                $stars = intval($data->stars);
                                                @endphp
                                                <div class="text-center">
                                                    @for($i=0;$i < $stars ; $i++) <i class="fa fa-star"
                                                        aria-hidden="true" style="color: coral;"></i>
                                                        @endfor
                                                </div>


                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-md-8 my-auto">
                                      <div class="form-group row">
                                          <label for="text" class="col-sm-4 col-form-label">Name</label>
                                          <div class="col-sm-8 col-form-label">
                                              <span>{{$data['userDetails']['name']}}</span>
                                          </div>
                                      </div>
                                      <div class="form-group row">
                                          <label for="inputEmail3" class="col-sm-4 col-form-label">Review</label>
                                          <div class="col-sm-8 col-form-label">
                                              <span>{{$data->reviews}} </span>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          @empty
                          <h6>No data found</h6>
                          @endforelse
                  </div>
              </div>
          </div>
      </div>
      <!-- /.card-body -->
  </div>
</div>
@endsection