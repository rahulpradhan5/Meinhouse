<div class="nav-header">
            <a href="{{url('admin/dashboard')}}" class="brand-logo">
				<img  class="logo-abbr" src="{{url('assets/jobick/images/logo.png')}}" width="auto" height="55.771" style="max-width:6rem" viewBox="0 0 62.074 65.771" alt="">
				<img  class="brand-title" src="{{url('assets/jobick/images/logo-img.png')}}" width="auto" height="50.771" style="margin-left:0px" viewBox="0 0 134.01 48.365"  alt="">
            </a>
            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        	
		<!--**********************************
            Chat box start
        ***********************************-->
		

		<!--**********************************
            Chat box End
        ***********************************-->
		
		<!--**********************************
            Header start
        ***********************************-->
        
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <ul class="navbar-nav header-right">
							
                        </ul>
                    </div>
				</nav>
			</div>
		</div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="dlabnav">
            <div class="dlabnav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="" href="{{url('pro/dashboard')}}">
							<i class="flaticon-025-dashboard"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                    </li>
                    <li><a class="" href="{{url('pro/leads')}}">
							<i class="flaticon-025-dashboard"></i>
							<span class="nav-text">Leads</span>
						</a>
                    </li>
					
                   <li><a class="" href="{{url('pro/estimate')}}" aria-expanded="false">
							<i class="flaticon-072-printer"></i>
							<span class="nav-text">Estimate</span>
						</a>
                   </li>

                   <li><a class="" href="{{url('pro/bidding')}}" aria-expanded="false">
							<i class="flaticon-043-menu"></i>
							<span class="nav-text">Biddings</span>
						</a>
                   </li>
					<li><a class="" href="{{url('pro/bookings')}}" aria-expanded="false">
							<i class="flaticon-093-waving"></i>
							<span class="nav-text">Bookings</span>
						</a>
                    </li>
                    <li><a class="" href="{{url('pro/proff-documents')}}">
						<i class="fa fa-user"></i>
							<span class="nav-text">Update Documents</span>
						</a>
                    </li>
                   <li><a class="" href="{{url('pro/proff-banking')}}">
							<i class="flaticon-041-graph"></i>
							<span class="nav-text">Update Banking</span>
						</a>
                   </li>
					<li><a href="{{url('pro/proff-business')}}" class="" >
							<i class="flaticon-013-checkmark"></i>
							<span class="nav-text">Update Business</span>
						</a>
					</li>
                   <li><a class="" href="{{url('pro/proff-availability')}}">
							<i class="flaticon-086-star"></i>
							<span class="nav-text">Update Availability</span>
						</a>
                   </li>
                   <li><a class="" href="{{url('pro/proff-customer-reviews')}}">
							<i class="flaticon-045-heart"></i>
							<span class="nav-text">Customer Reviews</span>
						</a>
                   </li>
     
                   <!-- <li><a class="" href="{{url('admin/promo')}}" aria-expanded="false">
							<i class="flaticon-022-copy"></i>
							<span class="nav-text">Promo Code</span>
						</a>
                   </li> -->
					<!-- <li><a class="" href="{{url('admin/testimonials')}}">
						<i class="mdi mdi-format-quote-open"></i>
							<span class="nav-text">Testimonials</span>
						</a>
                   </li> -->
				   <li><a class="" href="{{url('pro/edit-profile')}}" aria-expanded="false">
							<i class="flaticon-093-waving"></i>
							<span class="nav-text">Edit Profile</span>
						</a>
                    </li>
					<li><a href="{{url('pro/change-password')}}" class="" >
							<i class="flaticon-013-checkmark"></i>
							<span class="nav-text">Change Password</span>
						</a>
					</li>
                   <li><a class="" href="{{url('pro/terms-condition')}}">
							<i class="flaticon-086-star"></i>
							<span class="nav-text">Terms and Conditions</span>
						</a>
                   </li>
					<li><a class="" href="{{url('pro/about')}}">
							<i class="flaticon-041-graph"></i>
							<span class="nav-text">About Us</span>
						</a>
					</li>
					<li><a class="" href="{{url('pro-logout')}}">
							<i class="fa fa-sign-out-alt"></i>
							<span class="nav-text">Log Out</span>
						</a>
                    </li>
                </ul>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		