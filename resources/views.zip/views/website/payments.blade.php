<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        section.pricing {
            background: #007bff;
            background: linear-gradient(to right, #0062E6, #33AEFF);
        }

        .pricing .card {
            border: none;
            border-radius: 1rem;
            transition: all 0.2s;
            box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
        }

        .pricing hr {
            margin: 1.5rem 0;
        }

        .pricing .card-title {
            margin: 0.5rem 0;
            font-size: 0.9rem;
            letter-spacing: .1rem;
            font-weight: bold;
        }

        .pricing .card-price {
            font-size: 3rem;
            margin: 0;
        }

        .pricing .card-price .period {
            font-size: 0.8rem;
        }

        .pricing ul li {
            margin-bottom: 3rem;
        }

        .pricing .text-muted {
            opacity: 0.7;
        }

        .pricing .btn {
            font-size: 80%;
            border-radius: 5rem;
            letter-spacing: .1rem;
            font-weight: bold;
            padding: 1rem;
            opacity: 0.7;
            transition: all 0.2s;
        }

        /* Hover Effects on Card */

        @media (min-width: 992px) {
            .pricing .card:hover {
                margin-top: -.25rem;
                margin-bottom: .25rem;
                box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.3);
            }

            .pricing .card:hover .btn {
                opacity: 1;
            }
        }

        #card-element {
            border: 1px solid silver;
            border-radius: 4px;
            height: 35px;
            background: #fff;
            margin-bottom: 20px;
            padding-top: 10px;
        }
    </style>
</head>
@php
        $stripe_key = env("STRIPE_KEY");
    @endphp
<body>
    <section class="pricing py-5" style='height:auto'>
        <div class="container">
            <div class="row" style="margin-top: 25px;">
                <!-- Free Tier -->
                <div class="col-lg-2"></div>
                <div class="col-lg-8">
                    <div class="card mb-5 mb-lg-0">
                        <div class="card-body">
                            <h6 class="card-price text-center" style="font-size:30px;font-weight:600">Monthly Package
                            </h6>
                            <hr>
                            <ul class="fa-ul">
                                <li><span class="fa-li"><i class="fas fa-check"></i></span>Membership monthly
                                    charges<span class="period" style="float:right;
                                    color: #fda12b;font-weight: bold;">$79.99</span></li>
                                <li><span class="fa-li"><i class="fas fa-check"></i></span>Per Additional service
                                    charges<span class="period" style="float:right;
                                  color: #fda12b;font-weight: bold;">$ {{$monthly_amount}}</span></li>
                                <hr>
                                <li style="list-style-type: none;">Total amount payable<span class="period"
                                        style="float:right;font-weight: bold;color: #fda12b;">$
                                        {{$total_monthly}}</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2"></div>
                <div class="col-lg-8 mx-auto mt-5">
                  <div class="card">
                    <div class="card-body">
                      <form action="{{url('pro-payment-post')}}"  method="post" id="payment-form">
                          @csrf                    
                          <div class="form-group">
                              <div class="card-body text-center">
                              <h6 class="text-center mb-1" style="font-size:25px;font-weight:600">Complete Your Payment</h6>
                              <!-- <input id="card-holder-name" class="form-control" name="cardHolderName" placeholder="Enter Card Holder Name" type="text" style="margin-bottom:20px;"> -->
                                  <div id="card-element">
                                  <!-- A Stripe Element will be inserted here. -->
                                  </div>
                                  <!-- Used to display form errors. -->
                                  <div id="card-errors" role="alert"></div>
                                  <input type="hidden" name="plan" value="" />
                                  <input type="hidden" name="id" value="{{$payment_intent->id}}" />
                                  <button type="button" class="btn mx-auto text-center" style="color:white;font-weight:bold;background:green;opacity:1" id="card-button"  data-secret="{{ $intent }}">
                                    Pay Now
                                  </button>

                              </div>
                              
                          </div>
                      </form>

                    </div>
                  </div>
                </div>
            </div>

        </div>
        </div>
    </section>
</body>
<script src="https://js.stripe.com/v3/"></script>
<script>
    // Custom styling can be passed to options when creating an Element.
    // (Note that this demo uses a wider set of styles than the guide below.)

    var style = {
        base: {
            color: '#32325d',
            lineHeight: '18px',
            fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
            fontSmoothing: 'antialiased',
            fontSize: '16px',
            '::placeholder': {
                color: '#aab7c4'
            }
        },
        invalid: {
            color: '#fa755a',
            iconColor: '#fa755a'
        }
    };

    const stripe = Stripe('{{ $stripe_key }}', { locale: 'en' }); // Create a Stripe client.
    const elements = stripe.elements(); // Create an instance of Elements.
    const cardElement = elements.create('card', { style: style }); // Create an instance of the card Element.
    const cardButton = document.getElementById('card-button');
    const clientSecret = cardButton.dataset.secret;

    cardElement.mount('#card-element'); // Add an instance of the card Element into the `card-element` <div>.

    // Handle real-time validation errors from the card Element.
    cardElement.addEventListener('change', function (event) {
        var displayError = document.getElementById('card-errors');
        if (event.error) {
            displayError.textContent = event.error.message;
        } else {
            displayError.textContent = '';
        }
    });

    // Handle form submission.
    var form = document.getElementById('payment-form');

    form.addEventListener('submit', function (event) {
      console.log("click")
        event.preventDefault();

        stripe.handleCardPayment(clientSecret, cardElement, {
            payment_method_data: {
                // billing_details: { name: cardHolderName.value }
            }
        })
            .then(function (result) {
                console.log(result);
                if (result.error) {
                    // Inform the user if there was an error.
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = result.error.message;
                } else {
                    console.log(result);
                    form.submit();
                }
            });
    });
</script>

</html>