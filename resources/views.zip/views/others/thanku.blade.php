
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Animated thank you page template free download |  thank you page design in html with source code</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Anton&family=Righteous&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="http://schauhan.in/Examples/thankyou/style.css" />
</head>

<body>

  
            <div class="box">
               <h1>Thank You</h1>
               <p>Thank you for accepting the request</p>
               <div class="pyro">
                 <div class="before"></div>
                 <div class="after"></div>
               </div>
            </div>
        

</body>
</html>
